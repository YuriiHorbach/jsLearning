
//task1
console.log('Yurii Horbach');

//task2
console.log('2-7-1984');

//task3
console.log('Добро ' + 'пожаловать ' + ' на курс');


//task4
//alert(2019); 

//task5
//alert(2019 - 200); 


//task6
document.getElementById('one').innerHTML = 'Hello world';

//task7
document.getElementById('two').innerHTML = 12 * 12;

//task8
document.querySelector('.one').innerHTML = 'Hello world';

//task9
document.querySelector('h2 span').innerHTML = 'world';

//task10
document.querySelector('.three').innerHTML = '<h3>some text</h3>';

//task11
document.querySelector('.four').innerHTML += '<h2>header</h2> <p>text</p>';


//task12
let a = document.querySelector('.five').innerHTML = 3.1415;

//task13
let div7 = document.querySelector('.seven').innerHTML = '<img src="https://cdn4.iconfinder.com/data/icons/food-and-drink-flat-gradient/32/cone_ice_cream_food_drink_sweet-512.png" alt="">';


//task14
let z1 = 6;
let z2 = 3;

document.querySelector('.task14').innerHTML = z1 * z2;


//task15
let y1 = 6;
let y2 = 3;

document.querySelector('.task15').innerHTML = y1 / y2;

//task16
let x1 = 'Hello';
let x2 = 5;

document.querySelector('.task16').innerHTML = x1 + x2;

//task17
let d1 = document.querySelector('.test-1');
console.log(d1);

//task18
let d2 = document.querySelector('.test-2');
console.log(d2);
d2 = 5;
console.log(d2);

//task19
let divS3 = document.querySelector('.s3');
console.log(divS3);
divS3 = document.querySelector('.s4');
console.log(divS3);

//task20
// document.querySelector('body').innerHTML = '';